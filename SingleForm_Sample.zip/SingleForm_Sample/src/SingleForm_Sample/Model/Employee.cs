﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace SingleForm_Sample.Model
{
    public class Employee
    {
        [BsonId]
        public ObjectId Id { get; set; }

        public string Emp_Id { get; set; }

        [Required(ErrorMessage = "First Name is Requred.")]
        [DataType(DataType.Text, ErrorMessage = "Enter only Text value."), StringLength(50)]
        public string First_Name { get; set; }

        [Required(ErrorMessage = "Last Name is Requred.")]
        [DataType(DataType.Text, ErrorMessage = "Enter only Text value."), StringLength(50)]
        public string Last_Name { get; set; }

        [Required(ErrorMessage = "Email is Requred.")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter Valid Email."), StringLength(50)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Post is Requred.")]         
        public List<string> Post { get; set; }
      
        
        [DataType(DataType.MultilineText, ErrorMessage = "Max Length is 500 character for Description."), StringLength(500)]
        public string Description { get; set; }

        public DateTime date { get; set; }


    }
}
