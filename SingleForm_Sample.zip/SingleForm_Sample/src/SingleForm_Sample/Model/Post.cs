﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SingleForm_Sample.Model
{
    public class Post
    {
        [BsonId]
        public ObjectId Id { get; set; }

        [Required(ErrorMessage = "Serial Number is Requred.")]      
        public long serialNo { get; set; }

        [Required(ErrorMessage = "Post Name is Requred.")]
        [DataType(DataType.Text, ErrorMessage = "Enter only Text value."), StringLength(50)]       
        public string Post_Name { get; set; }       
        public string Description { get; set; }
        public bool status { get; set; }
        public DateTime date { get; set; }
    }
}
