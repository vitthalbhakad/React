﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SingleForm_Sample.Model;
using SingleForm_Sample.Common;
using Microsoft.AspNetCore.Mvc.Rendering;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace SingleForm_Sample.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: /<controller>/

    
            public IActionResult Index()
            {
                DbConfiguration obj = new DbConfiguration();
                var data = obj.PostDropDownData();
                ViewBag.PostList = data.Select(N => new SelectListItem { Text = N.Post_Name, Value = N.serialNo.ToString() });
                return View();
            }


            [HttpPost]
            public IActionResult Index(Employee collection)
            {
                try
                {
                if (collection.Post !=null)
                {
                    if (collection.Post[0] == "select")
                    {
                        List<ReturnStatus> list = new List<ReturnStatus>();
                        foreach (var model in ModelState)
                        {
                            if (model.Value.ValidationState.ToString() == "Invalid")
                            {
                                ReturnStatus obj2 = new ReturnStatus();
                                obj2.value = Convert.ToString(model.Key);
                                obj2.message = Convert.ToString(model.Value.Errors[0].ErrorMessage);
                                list.Add(obj2);
                            }

                        }                      
                        ReturnStatus obj = new ReturnStatus();
                        obj.value = "Post";
                        obj.message = "Plese Select Valid Post";
                        list.Add(obj);
                        return Json(new { status = "error", data = list, length = ModelState.ErrorCount + 1 });

                    }
                }
                if (ModelState.IsValid)
                    {

                        DbConfiguration obj = new DbConfiguration();
                        if (obj.isEmployeeId_Dublicate(collection.Email))
                        {
                        List<ReturnStatus> list = new List<ReturnStatus>();
                        ReturnStatus rs = new ReturnStatus();
                        rs.value = "Email";
                        rs.message = "Email is already exist in database,Please try with different email.";
                        list.Add(rs);
                        return Json(new { status = "error", data = list, length = 1 });
                        // return Json(new JsonResult("Email ID - " + collection.Email + "  already exist in database."));
                    }
                        else
                        {
                            Employee std = new Employee();
                            long lastSerialno = obj.LastEmployeeRecordID();
                            std.Emp_Id = Convert.ToString("Emp-" + DateTime.Now.Month + DateTime.Now.Year + "-" + (lastSerialno + 1));
                            std.First_Name = collection.First_Name;
                            std.Last_Name = collection.Last_Name;
                            std.Description = collection.Description;
                            std.Post = collection.Post;
                            std.Email = collection.Email;
                            std.date = DateTime.Now;
                            obj.InsertEmployee(std);

                            return Json(new { status = "success", value = "Employee Added Successfully." });
                        }

                    }
                    else
                    {

                    List<ReturnStatus> list=new List<ReturnStatus>();
                    foreach (var model in ModelState)
                    {
                        if (model.Value.ValidationState.ToString()=="Invalid")
                        {
                            ReturnStatus obj = new ReturnStatus();
                            obj.value=Convert.ToString(model.Key);
                            obj.message = Convert.ToString(model.Value.Errors[0].ErrorMessage);
                            list.Add(obj);
                        }
                       
                    }
                        return Json(new { status = "error", data =list,length= ModelState.ErrorCount });
                    
                    }

                }
                catch (Exception ex)
                {
                    return Json(new { status = "error", value = "Something went wrong." });
                }

            }

            [HttpPost]
            public IActionResult LoadData()
            {
                var draw = HttpContext.Request.Form["draw"].FirstOrDefault();
                // Skiping number of Rows count  
                var start = Request.Form["start"].FirstOrDefault();
                // Paging Length 10,20  
                var length = Request.Form["length"].FirstOrDefault();
                // Sort Column Name  
                var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
                // Sort Column Direction ( asc ,desc)  
                var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
                // Search Value from (Search box)  
                var s = Request.Form["search[value]"].FirstOrDefault();

                // Paging Size (5,10,15,20)  
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;

                //Getting all Customer data  
                DbConfiguration obj = new DbConfiguration();
               List<Employee> data = obj.LoadEmployeeData(sortColumn, sortColumnDirection);
               
                if (!string.IsNullOrEmpty(s))
                {               
                  data= data.FindAll(m => m.First_Name.ToLower().Contains(s.ToLower()) || m.Last_Name.ToLower().Contains(s.ToLower()) || m.Email.ToLower().Contains(s.ToLower()) || m.Emp_Id.ToLower().Contains(s.ToLower()) || m.Post.Contains(s) || m.Post.Contains(s.ToLower()) || m.Post.Contains(s.ToUpper())).ToList();
               
                 }
                //total number of rows count   
                recordsTotal = data.Count();
                //Paging   
                var data22 = data.Skip(skip).Take(pageSize).ToList();
                return Json(new
                {
                    recordsFiltered = recordsTotal,
                    recordsTotal = recordsTotal,
                    data = data22
                });
            }




            public IActionResult Delete(string id)
            {
                try
                {
                    DbConfiguration obj = new DbConfiguration();                            
                if (!obj.IsEmplyeeRecuiter(id))
                {
                    obj.DeleteEmplyee(id);
                    return Json(new { status = "success", message = "Record Deleted Successfully." });
                }
                else
                {
                    return Json(new { status = "success", message = "The recruiter is already been assinged to candidate.So can't be deleted." });
                }
            }
                catch (Exception ex)
                {
                    return Json(new { status = "error", message = "Something Went Wrong." });
                }

            }


            [HttpGet]
            public IActionResult Edit(string id)
        {
            try
            {
                DbConfiguration obj = new DbConfiguration();
              Employee record=  obj.SingleEmployee(id);
                return Json(new { status = "success",data= record, message = "Record retrived successfully." });
            }
            catch (Exception ex)
            {
                return Json(new { status = "error", message = "Something Went Wrong." });
            }
        }

            [HttpPost]
            public IActionResult Edit(Employee collection)
        {
            try
            {
                if (collection.Post != null)
                {
                    if (collection.Post[0] == "select")
                    {
                        List<ReturnStatus> list = new List<ReturnStatus>();
                        foreach (var model in ModelState)
                        {
                            if (model.Value.ValidationState.ToString() == "Invalid")
                            {
                                ReturnStatus obj2 = new ReturnStatus();
                                obj2.value = Convert.ToString(model.Key);
                                obj2.message = Convert.ToString(model.Value.Errors[0].ErrorMessage);
                                list.Add(obj2);
                            }

                        }
                        ReturnStatus obj = new ReturnStatus();
                        obj.value = "Post";
                        obj.message = "Plese Select Valid Post";
                        list.Add(obj);
                        return Json(new { status = "error", data = list, length = ModelState.ErrorCount + 1 });

                    }
                }
                if (ModelState.IsValid)
                {

                    DbConfiguration obj = new DbConfiguration();
                    if (obj.IsEmployeeEmailExist(collection.Email,collection.Emp_Id))
                    {
                        List<ReturnStatus> list = new List<ReturnStatus>();
                        ReturnStatus rs = new ReturnStatus();
                        rs.value = "Email";
                        rs.message = "Email is already exist in database,Please try with different email.";
                        list.Add(rs);
                        return Json(new { status = "error", data = list, length =1 });
                        // return Json(new JsonResult("Email ID - " + collection.Email + "  already exist in database."));
                    }
                    else
                    {                      
                        obj.updateEmployee(collection,collection.Emp_Id);

                        return Json(new { status = "success", value = "Employee updated successfully." });
                    }

                }
                else
                {

                    List<ReturnStatus> list = new List<ReturnStatus>();
                    foreach (var model in ModelState)
                    {
                        if (model.Value.ValidationState.ToString() == "Invalid")
                        {
                            ReturnStatus obj = new ReturnStatus();
                            obj.value = Convert.ToString(model.Key);
                            obj.message = Convert.ToString(model.Value.Errors[0].ErrorMessage);
                            list.Add(obj);
                        }

                    }
                    return Json(new { status = "error", data = list, length = ModelState.ErrorCount });

                }

            }
            catch (Exception ex)
            {
                return Json(new { status = "error", value = "Something went wrong." });
            }

        }
    }

    public class ReturnStatus
    {
        public string value { get; set; }
        public string message { get; set; }
    }
}
