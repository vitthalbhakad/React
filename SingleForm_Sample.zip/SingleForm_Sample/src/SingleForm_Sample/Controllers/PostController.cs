﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SingleForm_Sample.Model;
using SingleForm_Sample.Common;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace SingleForm_Sample.Controllers
{
    public class PostController : Controller
    {
        // GET: /<controller>/
       
        public IActionResult Index()
        {          
            return View();
        }

        [HttpPost]
        public IActionResult Index(Post collection)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    DbConfiguration obj = new DbConfiguration();
                    if (obj.isPost_Dublicate(collection.Post_Name))
                    {
                        Post std = new Post();
                        std.Post_Name = collection.Post_Name;                                               
                        return Json(new JsonResult("Post name  " + collection.Post_Name + "  already exist in database."));
                    }
                    else
                    {
                        Post std = new Post();
                        long lastSerialno = obj.LastRecordID();
                        std.serialNo = lastSerialno + 1;
                        std.Post_Name = collection.Post_Name;
                        std.Description = collection.Description;
                        std.status = collection.status;
                        std.date = DateTime.Now;
                        obj.InsertPost(std);

                      
                        return Json(new {status="success", value="Post Added Successfully." });
                    }

                }
                else
                {                                                                      
                    return Json(new JsonResult("Please enter Post name."));
                    //return View();
                }

            }
            catch
            {
                return Json(new {status="error", value = "Something went wrong." });
            }

        }

        [HttpPost]
        public IActionResult LoadData()
        {
            var draw = HttpContext.Request.Form["draw"].FirstOrDefault();
            // Skiping number of Rows count  
            var start = Request.Form["start"].FirstOrDefault();
            // Paging Length 10,20  
            var length = Request.Form["length"].FirstOrDefault();
            // Sort Column Name  
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            // Sort Column Direction ( asc ,desc)  
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            // Search Value from (Search box)  
            var searchValue = Request.Form["search[value]"].FirstOrDefault();

            // Paging Size (5,10,15,20)  
            int pageSize = length != null ? Convert.ToInt32(length) : 0;
            int skip = start != null ? Convert.ToInt32(start) : 0;
            int recordsTotal = 0;

            //Getting all Customer data  
            DbConfiguration obj = new DbConfiguration();
            IEnumerable<Post> data = obj.LoadPostData(sortColumn, sortColumnDirection);
            //Sorting  
            // if (!(string.IsNullOrEmpty(sortColumn) && string.IsNullOrEmpty(sortColumnDirection)))
            // {                
            //    data = data = obj.LoadPostData(sortColumn, sortColumnDirection) ;
            // }
            //Search  
            if (!string.IsNullOrEmpty(searchValue))
            {
                data = data.Where(m => m.Post_Name == searchValue);
            }

            //total number of rows count   
            recordsTotal = data.Count();
            //Paging   
            var data22 = data.Skip(skip).Take(pageSize).ToList();
            return Json(new
            {
                recordsFiltered = recordsTotal,
                recordsTotal = recordsTotal,
                data = data22          
            });
        }

        [HttpGet]
        public IActionResult Insert()
        {
            Post std = new Post();
            std.Post_Name ="";
            std.Description = "";
            std.status =true;
            std.date = DateTime.Now;
            return View(std);
        }

        [HttpPost]
        public IActionResult Insert(Post collection)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    
                    DbConfiguration obj = new DbConfiguration();
                    if (obj.isPost_Dublicate(collection.Post_Name))
                    {
                        Post std = new Post();
                        std.Post_Name = collection.Post_Name;
                        ViewBag.isDublicatePost = "Post name  " + collection.Post_Name + "  already exist in database.";
                        return View();
                    }
                    else
                    {                      
                        Post std = new Post();
                        long lastSerialno = obj.LastRecordID();                      
                        std.serialNo = lastSerialno + 1;
                        std.Post_Name = collection.Post_Name;
                        std.Description = collection.Description;
                        std.status = collection.status;
                        std.date = DateTime.Now;
                        obj.InsertPost(std);
                        return RedirectToAction("Index");
                    }
                  
                }
                else
                {
                    return View();
                }

            }
            catch
            {
                return View();
            }

        }

   
        public IActionResult Delete(string id)
        {
            try
            {
                DbConfiguration obj = new DbConfiguration();
                obj.DeletePost(id);
                return Json(new { status = "success", message = "Record Deleted Successfully." });
            }catch(Exception ex)
            {
                return Json(new { status = "error", message = "Something Went Wrong." });
            }
           
        }
    }
}
