﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SingleForm_Sample.Model;
using SingleForm_Sample.Common;
using Microsoft.AspNetCore.Mvc.Rendering;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace SingleForm_Sample.Controllers
{
    public class CandidateController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            DbConfiguration obj = new DbConfiguration();
            var data = obj.EmployeeDropDownData();
            ViewBag.EmployeeList = data.Select(N => new SelectListItem { Text = N.First_Name, Value = N.Emp_Id.ToString() });
            return View();
        }


        [HttpPost]
        public IActionResult Index(Candidate collection)
        {
            try
            {
                if (collection.Recruiter != null)
                {
                    if (collection.Recruiter[0] == "select")
                    {
                        List<ReturnStatus> list = new List<ReturnStatus>();
                        foreach (var model in ModelState)
                        {
                            if (model.Value.ValidationState.ToString() == "Invalid")
                            {
                                ReturnStatus obj2 = new ReturnStatus();
                                obj2.value = Convert.ToString(model.Key);
                                obj2.message = Convert.ToString(model.Value.Errors[0].ErrorMessage);
                                list.Add(obj2);
                            }

                        }
                        ReturnStatus obj = new ReturnStatus();
                        obj.value = "Recruiter";
                        obj.message = "Plese Select Valid Recuiter";
                        list.Add(obj);
                        return Json(new { status = "error", data = list, length = ModelState.ErrorCount + 1 });

                    }
                }
                if (ModelState.IsValid)
                {

                    DbConfiguration obj = new DbConfiguration();
                    if (obj.isEmailId_exist(collection.Email))
                    {
                        List<ReturnStatus> list = new List<ReturnStatus>();
                        ReturnStatus rs = new ReturnStatus();
                        rs.value = "Email";
                        rs.message = "Email is already exist in database,Please try with different email.";
                        list.Add(rs);
                        return Json(new { status = "error", data = list, length = 1 });
                        //return Json(new JsonResult("Email ID - " + collection.Email + "  already exist in database."));
                    }
                    else
                    {
                        Candidate std = new Candidate();
                        long lastSerialno = obj.LastCandidateRecordID();
                        std.Can_Id = Convert.ToString("Can-" + DateTime.Now.Month + DateTime.Now.Year + "-" + (lastSerialno + 1));
                        std.First_Name = collection.First_Name;
                        std.Last_Name = collection.Last_Name;
                        std.Description = collection.Description;
                        std.Recruiter = collection.Recruiter;
                        std.Email = collection.Email;
                        std.CreateDate = DateTime.Now;
                        std.UpdatedDate = DateTime.Now;
                        obj.InsertEmployee(std);                      
                        return Json(new { status = "success", value = "Candidate Added Successfully." });
                    }

                }
                else
                {

                    List<ReturnStatus> list = new List<ReturnStatus>();
                    foreach (var model in ModelState)
                    {
                        if (model.Value.ValidationState.ToString() == "Invalid")
                        {
                            ReturnStatus obj = new ReturnStatus();
                            obj.value = Convert.ToString(model.Key);
                            obj.message = Convert.ToString(model.Value.Errors[0].ErrorMessage);
                            list.Add(obj);
                        }

                    }
                    return Json(new { status = "error", data = list, length = ModelState.ErrorCount });

                }

            }
            catch (Exception ex)
            {
                return Json(new { status = "error", value = "Something went wrong." });
            }

        }

        [HttpPost]
        public IActionResult LoadData()
        {
            var draw = HttpContext.Request.Form["draw"].FirstOrDefault();
            // Skiping number of Rows count  
            var start = Request.Form["start"].FirstOrDefault();
            // Paging Length 10,20  
            var length = Request.Form["length"].FirstOrDefault();
            // Sort Column Name  
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            // Sort Column Direction ( asc ,desc)  
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            // Search Value from (Search box)  
            var s = Request.Form["search[value]"].FirstOrDefault();

            // Paging Size (5,10,15,20)  
            int pageSize = length != null ? Convert.ToInt32(length) : 0;
            int skip = start != null ? Convert.ToInt32(start) : 0;
            int recordsTotal = 0;

            //Getting all Customer data  
            DbConfiguration obj = new DbConfiguration();
            IEnumerable<Candidate> data = obj.LoadCandidateData(sortColumn, sortColumnDirection);
            
            //Search  
            if (!string.IsNullOrEmpty(s))
            {
                data = data.Where(m => m.First_Name.ToLower().Contains(s.ToLower()) || m.Last_Name.ToLower().Contains(s.ToLower()) || m.Email.ToLower().Contains(s.ToLower()) || m.Recruiter.Contains(s) || m.Recruiter.Contains(s.ToLower()) || m.Recruiter.Contains(s.ToUpper()));
            }
            //total number of rows count   
            recordsTotal = data.Count();
            //Paging   
            var data22 = data.Skip(skip).Take(pageSize).ToList();
            return Json(new
            {
                recordsFiltered = recordsTotal,
                recordsTotal = recordsTotal,
                data = data22
            });
        }




        public IActionResult Delete(string id)
        {
            try
            {
                //check this employee is  requireter or not
                DbConfiguration obj = new DbConfiguration();
                obj.DeleteCandidate(id);
                return Json(new { status = "success", message = "Record Deleted Successfully." });
            }
            catch (Exception ex)
            {
                return Json(new { status = "error", message = "Something Went Wrong." });
            }

        }


        [HttpGet]
        public IActionResult Edit(string id)
        {
            try
            {
                DbConfiguration obj = new DbConfiguration();
                Candidate record = obj.SingleCandidate(id);
                if(record != null)
                {
                    return Json(new { status = "success", data = record, message = "Record retrived successfully." });
                }else
                {
                    return Json(new { status = "error", message = "Something Went Wrong." });
                }
               
            }
            catch (Exception ex)
            {
                return Json(new { status = "error", message = "Something Went Wrong." });
            }
        }

        [HttpPost]
        public IActionResult Edit(Candidate collection)
        {
            try
            {
                if (collection.Recruiter != null)
                {
                    if (collection.Recruiter[0] == "select")
                    {
                        List<ReturnStatus> list = new List<ReturnStatus>();
                        foreach (var model in ModelState)
                        {
                            if (model.Value.ValidationState.ToString() == "Invalid")
                            {
                                ReturnStatus obj2 = new ReturnStatus();
                                obj2.value = Convert.ToString(model.Key);
                                obj2.message = Convert.ToString(model.Value.Errors[0].ErrorMessage);
                                list.Add(obj2);
                            }

                        }
                        ReturnStatus obj = new ReturnStatus();
                        obj.value = "Recruiter";
                        obj.message = "Plese Select Valid Recuiter";
                        list.Add(obj);
                        return Json(new { status = "error", data = list, length = ModelState.ErrorCount + 1 });

                    }
                }
                if (ModelState.IsValid)
                {

                    DbConfiguration obj = new DbConfiguration();
                    if (obj.IsCandidateEmailExist(collection.Email, collection.Can_Id))
                    {
                        List<ReturnStatus> list = new List<ReturnStatus>();
                        ReturnStatus rs = new ReturnStatus();
                        rs.value = "Email";
                        rs.message = "Email is already exist in database,Please try with different email.";
                        list.Add(rs);
                        return Json(new { status = "error", data = list, length = 1 });                      
                    }
                    else
                    {
                        obj.UpdateCandidate(collection, collection.Can_Id);

                        return Json(new { status = "success", value = "Employee updated successfully." });
                    }

                }
                else
                {

                    List<ReturnStatus> list = new List<ReturnStatus>();
                    foreach (var model in ModelState)
                    {
                        if (model.Value.ValidationState.ToString() == "Invalid")
                        {
                            ReturnStatus obj = new ReturnStatus();
                            obj.value = Convert.ToString(model.Key);
                            obj.message = Convert.ToString(model.Value.Errors[0].ErrorMessage);
                            list.Add(obj);
                        }

                    }
                    return Json(new { status = "error", data = list, length = ModelState.ErrorCount });

                }

            }
            catch (Exception ex)
            {
                return Json(new { status = "error", value = "Something went wrong." });
            }

        }
    }

   
}
