﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Driver.Core;
using MongoDB.Driver.Linq;
using SingleForm_Sample.Model;

namespace SingleForm_Sample.Common
{
    public class DbConfiguration
    {
             
        private readonly IMongoDatabase _database = null;
        //IGridFSBucket bucket;
        public DbConfiguration()
        {
            var client = new MongoClient("mongodb://localhost:27017");
            _database = client.GetDatabase("SingleForm3");          
        }
        #region Post CURD
        public IEnumerable<Post> LoadPostData()
        {
            return _database.GetCollection<Post>("Post").Find(FilterDefinition<Post>.Empty).ToList();
        }
        public IEnumerable<Post> PostDropDownData()
        {
            var fields = Builders<Post>.Projection.Include(p => p.serialNo).Include(p => p.Post_Name);             
            return _database.GetCollection<Post>("Post").Find(FilterDefinition<Post>.Empty).Project<Post>(fields).ToList();
        }
        public IEnumerable<Post> LoadPostData(string column,string direction)
        {
            if (!(string.IsNullOrEmpty(column) && string.IsNullOrEmpty(direction)))
            {
                var builder = Builders<Post>.Sort;
                if (direction == "asc")
                {
                    var sort = builder.Ascending(column=="" ? "serialNo" : column);
                    return _database.GetCollection<Post>("Post").Find(FilterDefinition<Post>.Empty).Sort(sort).ToList();
                }
                else
                {
                    var sort = builder.Descending(column == "" ? "serialNo" : column);
                    return _database.GetCollection<Post>("Post").Find(FilterDefinition<Post>.Empty).Sort(sort).ToList();
                }
               
            }
            else
            {
                var builder = Builders<Post>.Sort;
                var sort = builder.Ascending("serialNo");
                return _database.GetCollection<Post>("Post").Find(FilterDefinition<Post>.Empty).Sort(sort).ToList();
            }
            
        }
        public void InsertPost(Post post)
        {
            _database.GetCollection<Post>("Post").InsertOne(post);
        }

        public void DeletePost(string serialNo)
        {
            //ObjectId objid = new ObjectId(empId);
            var filter = Builders<Post>.Filter.Eq("serialNo", serialNo);
            _database.GetCollection<Post>("Post").DeleteOne(filter);
        }

        public bool isPost_Dublicate(string Post_Name)
        {           
            var filter = Builders<Post>.Filter.Eq("Post_Name", Post_Name);
            var count=_database.GetCollection<Post>("Post").Find(filter).Count();
            return count > 0 ? true : false; 
        }

        public long LastRecordID()
        {
            var builder = Builders<Post>.Sort;
            var sort = builder.Descending("Id");
            var CursorToResults = _database.GetCollection<Post>("Post").Find(FilterDefinition<Post>.Empty).Sort(sort).Limit(1);
            var record = CursorToResults.FirstOrDefault();
           
            return record.serialNo > 0 ? record.serialNo : 0;
        }

        #endregion

        #region Employee CURD
        public List<Employee> LoadEmployeeData(string column, string direction)
        {
           
            if (!(string.IsNullOrEmpty(column) && string.IsNullOrEmpty(direction)))
            {
                var builder = Builders<Employee>.Sort;
                if (direction == "asc")
                {                  
                   return _database.GetCollection<Employee>("Employee").Find(FilterDefinition<Employee>.Empty).Sort(Builders<Employee>.Sort.Ascending(column=="null"? "First_Name" : column)).ToList();
                }
                else
                {                    
                    return _database.GetCollection<Employee>("Employee").Find(FilterDefinition<Employee>.Empty).Sort(Builders<Employee>.Sort.Descending(column == "null" ? "First_Name" : column)).ToList();
                }

            }
            else
            {
                var builder = Builders<Employee>.Sort;
                var sort = builder.Ascending("Id");
                return _database.GetCollection<Employee>("Employee").Find(FilterDefinition<Employee>.Empty).Sort(sort).ToList();
            }

        }
        public void InsertEmployee(Employee employee)
        {
            _database.GetCollection<Employee>("Employee").InsertOne(employee);
        }
        public void updateEmployee(Employee employee, string Emp_Id)
        {           
            var result = _database.GetCollection<Employee>("Employee").FindOneAndUpdate(
                                 Builders<Employee>.Filter.Eq("Emp_Id", Emp_Id),
                                 Builders<Employee>.Update.Set("First_Name", employee.First_Name).Set("Last_Name", employee.Last_Name).Set("Post", employee.Post).Set("Email", employee.Email).Set("Description", employee.Description)
                                 );           
        }

        public void DeleteEmplyee(string serialNo)
        {
            var filter = Builders<Employee>.Filter.Eq("Emp_Id", serialNo);
            _database.GetCollection<Employee>("Employee").DeleteOne(filter);
        }

        public bool IsEmplyeeRecuiter(string serialNo)
        {
            var filter22 = Builders<Employee>.Filter.Eq("Emp_Id", serialNo);
            var Employee = _database.GetCollection<Employee>("Employee").Find(filter22).FirstOrDefault();
            bool check = false;                                    
                var candidate = _database.GetCollection<Candidate>("Candidate").Find(FilterDefinition<Candidate>.Empty).ToList();              
                if(candidate != null)
                {
                    foreach(var can in candidate)
                    {
                       var recuiter = can.Recruiter==null ? null : can.Recruiter;
                    foreach (var rec in recuiter)
                    {
                        if (rec==(Employee.First_Name==null ? null : Employee.First_Name))
                        {
                            check = true;
                        }

                    }
                  }
                }
                       
            return check;
           
        }
        public Employee SingleEmployee(string Emp_Id)
        {
            var filter = Builders<Employee>.Filter.Eq("Emp_Id", Emp_Id);
            var count = _database.GetCollection<Employee>("Employee").Find(filter).FirstOrDefault();
            return count;
        }
        public bool isEmployeeId_Dublicate(string Emp_Id)
        {
            var filter = Builders<Employee>.Filter.Eq("Email", Emp_Id);
            var count = _database.GetCollection<Employee>("Employee").Find(filter).Count();
            return count > 0 ? true : false;
        }
        public bool IsEmployeeEmailExist(string email,string Emp_Id)
        {
            var filter = Builders<Employee>.Filter.Eq("Email", email);
            var record = _database.GetCollection<Employee>("Employee").Find(filter).FirstOrDefault();
            var count = 0;
            if (record != null)
            {
                if (!(record.Email == email && record.Emp_Id == Emp_Id))
                {
                    count = 1;
                }
            }
            return count > 0 ? true : false;
        }

        public long LastEmployeeRecordID()
        {
            var builder = Builders<Employee>.Sort;
            var sort = builder.Descending("Id");
            var CursorToResults = _database.GetCollection<Employee>("Employee").Find(FilterDefinition<Employee>.Empty).Sort(sort).Limit(1);
            var record = CursorToResults.FirstOrDefault();
            long lastPart = 0;
            if(record != null)
            {
                if (!(string.IsNullOrEmpty(record.Emp_Id)))
                {
                    lastPart = Convert.ToInt16(record.Emp_Id.Substring(record.Emp_Id.LastIndexOf("-") + 1));
                }
            }
                                 
            return lastPart;
        }
        #endregion

        #region Candidate CURD

        public bool isEmailId_exist(string Emp_Id)
        {
            var filter = Builders<Candidate>.Filter.Eq("Email", Emp_Id);
            var count = _database.GetCollection<Candidate>("Candidate").Find(filter).Count();
            return count > 0 ? true : false;
        }
        public long LastCandidateRecordID()
        {
            var builder = Builders<Candidate>.Sort;
            var sort = builder.Descending("Id");
            var CursorToResults = _database.GetCollection<Candidate>("Candidate").Find(FilterDefinition<Candidate>.Empty).Sort(sort).Limit(1);
            var record = CursorToResults.FirstOrDefault();
            long lastPart = 0;
            if (record != null)
            {
                if (!(string.IsNullOrEmpty(record.Can_Id)))
                {
                    lastPart = Convert.ToInt16(record.Can_Id.Substring(record.Can_Id.LastIndexOf("-") + 1));
                }
            }

            return lastPart;
        }

        public Candidate SingleCandidate(string Can_Id)
        {
            var filter = Builders<Candidate>.Filter.Eq("Can_Id", Can_Id);
            var count = _database.GetCollection<Candidate>("Candidate").Find(filter).FirstOrDefault();
            return count;
        }
        public IEnumerable<Employee> EmployeeDropDownData()
        {
            var fields = Builders<Employee>.Projection.Include(p => p.Emp_Id).Include(p => p.First_Name);
            return _database.GetCollection<Employee>("Employee").Find(FilterDefinition<Employee>.Empty).Project<Employee>(fields).ToList();
        }
        public IEnumerable<Candidate> LoadCandidateData(string column, string direction)
        {

            if (!(string.IsNullOrEmpty(column) && string.IsNullOrEmpty(direction)))
            {
                var builder = Builders<Candidate>.Sort;
                if (direction == "asc")
                {
                    return _database.GetCollection<Candidate>("Candidate").Find(FilterDefinition<Candidate>.Empty).Sort(Builders<Candidate>.Sort.Ascending(column)).ToList();
                }
                else
                {
                    return _database.GetCollection<Candidate>("Candidate").Find(FilterDefinition<Candidate>.Empty).Sort(Builders<Candidate>.Sort.Descending(column)).ToList();
                }

            }
            else
            {
                var builder = Builders<Candidate>.Sort;
                var sort = builder.Ascending("Id");
                return _database.GetCollection<Candidate>("Candidate").Find(FilterDefinition<Candidate>.Empty).Sort(sort).ToList();
            }

        }

        public void InsertEmployee(Candidate Candidate)
        {
            _database.GetCollection<Candidate>("Candidate").InsertOne(Candidate);
        }

        public bool IsCandidateEmailExist(string email, string Emp_Id)
        {
            var filter = Builders<Candidate>.Filter.Eq("Email", email);
            var record = _database.GetCollection<Candidate>("Candidate").Find(filter).FirstOrDefault();
            var count = 0;
            if (record != null)
            {
                if (!(record.Email == email && record.Can_Id == Emp_Id))
                {
                    count = 1;
                }
            }
            return count > 0 ? true : false;
        }

        public void UpdateCandidate(Candidate Candidate, string Can_Id)
        {
            var result = _database.GetCollection<Candidate>("Candidate").FindOneAndUpdate(
                                 Builders<Candidate>.Filter.Eq("Can_Id", Can_Id),
                                 Builders<Candidate>.Update.Set("First_Name", Candidate.First_Name).Set("Last_Name", Candidate.Last_Name).Set("Recruiter", Candidate.Recruiter).Set("Email", Candidate.Email).Set("Description", Candidate.Description).Set("UpdatedDate",DateTime.Now)
                                 );
        }

        public void DeleteCandidate(string serialNo)
        {
            var filter = Builders<Candidate>.Filter.Eq("Can_Id", serialNo);
            _database.GetCollection<Candidate>("Candidate").DeleteOne(filter);
        }
        #endregion

    }
}
